#ifndef _LMS_H_
#define _LMS_H_
#include "ap_cint.h"
#define Order	10000
#define N       10000
#define SAMPLES N
typedef short	coe_length;
typedef short	data_length;
typedef int38	data_out;
#endif
